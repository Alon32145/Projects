// Name: Alon
// ID:   109763201
// Email: araigorodetsky@myseneca.ca
// Date:  7/31/2021
// Add the text to the <span>...<span> element in the element with id=table-title
function updateTableTitle(title) {
  console.log("title: ", title);
  // TODO
  document.getElementById("card-title").innerText = title;
}

function addRowToTable(card) {
  const div = document.querySelector("#observation-data");
  div.appendChild(card);
}

function clearAllTableRows() {
  const div = document.querySelector("#observation-data");
  div.innerHTML = "";
}

// Creates and returns new table row <tr> element with the specified id value.
function createTableRow(id) {
  // TODO
  var tr = document.createElement("tr");
  tr.id = id;
  return tr;
}

// Given a child element, create a <td> and add this child to it. Return the <td>.
function createTableCell(child) {
  // TODO
  var td = document.createElement("td");
  td.appendChild(child);
  return td;
}

// Wraps a child element in a <td>...</td> and adds it to the table row
function addContentToRow(child, row) {
  // TODO
  var td = document.createElement("td");
  td.appendChild(child);
  row.appendChild(td);
}

// Given a URL src string and alt text string, create an <img> element and return:
// <img src="https://static.inaturalist.org/photos/109319291/square.jpg?1609877680" alt="Muskrat">
function createImg(src, alt) {
  // TODO
  var img = document.createElement("img");
  img.src = src;
  img.alt = alt;
  return img;
}

// Given a string of text, create and return a TextNode
// https://developer.mozilla.org/en-US/docs/Web/API/Document/createTextNode
function createText(text) {
  // TODO
  var node = document.createTextNode(text);
  return node;
}

// create and return an anchor element.
// <a href="http://en.wikipedia.org/wiki/Muskrat">Muskrat</a>.  NOTE:
// The innerContent will be a TextNode or HTML Img Element (i.e., it
// won't be simple text).
function createAnchor(href, innerContent) {
  var anch = document.createElement("a");
  anch.href = href;
  anch.innerText = innerContent;
  return anch;
}

// Return a proper time element with its dateTime property set:
// <time datetime="2020-09-18">2020-09-18</time>
function createTime(formatted) {
  var date = new Date(formatted);
  var year = date.getFullYear();
  var month = ("0" + (date.getMonth() + 1)).slice(-2);
  var day = ("0" + date.getDate()).slice(-2);
  var final = year + "-" + month + "-" + day;
  var time = document.createElement("time");
  time.datetime = final;
  var txt = document.createTextNode(final);
  time.appendChild(txt);
  return time;
}

// Given a boolean value (true/false) return a string "Yes" or "No"
function toYesNo(value) {
  // TODO
  if (value) {
    return "Yes";
  } else {
    return "No";
  }
}

// Converts an Observation object into DOM nodes that produce the following HTML:
//
//  <tr id="67868131">
//    <td>
//      <a href="https://www.inaturalist.org/observations/67868131">
//        <img
//          src="https://static.inaturalist.org/photos/109319291/square.jpg?1609877680"
//          alt="Muskrat">
//      </a>
//    </td>
//    <td>
//      <time datetime="2020-09-18">2020-09-18</time>
//    </td>
//    <td>
//      <a href="http://en.wikipedia.org/wiki/Muskrat">Muskrat</a>
//    </td>
//    <td>No</td>
//    <td>Yes</td>
//    <td>No</td>
//    <td>No</td>
//  </tr>
//
// Things to note in your solution:
//
// - Give the table row an id, using the observation's id
// - Create an anchor so you can click the photo and go to the observation's uri
// - Use the observation's name as the alt text of the image, and photoUrl as its src
// - Use a proper <time> element, and format the observation's date using a locale aware format, see
//   https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toLocaleDateString
// - Use the observation's wikipediaUrl to provide a link when you click the name
// - Convert all the boolean values for endangered, native, threatened, introduced to "Yes" or "No" strings
function buildRowForObservation(observation) {
  // 1. Create the row for this observation with correct id: <tr id="67868131">...</tr>
  const row = createTableRow(observation.id);

  // 2. Create the photo, make it a link to the observation page, and put it in the first cell
  // <img src="https://static.inaturalist.org/photos/109762131/square.jpg?1610308133">
  const photo = createImg(observation.photoUrl, observation.name);
  // <a href="https://www.inaturalist.org/observations/67868131">...</a>
  const observationLink = createAnchor(observation.uri, photo);
  // <td>...</td>
  addContentToRow(observationLink, row);

  const time = createTime(
    observation.date.toLocaleDateString(),
    observation.date
  );
  addContentToRow(time, row);

  const name = createText(observation.name);
  const wikipediaLink = createAnchor(observation.wikipediaUrl, name);
  addContentToRow(wikipediaLink, row);

  ["isEndangered", "isNative", "isThreatened", "isIntroduced"].forEach(
    (characteristic) => {
      const yesNoText = toYesNo(observation[characteristic]);
      const yesNoNode = createText(yesNoText);
      addContentToRow(yesNoNode, row);
    }
  );

  return row;
}

// assignment 5
function buildCardForObservation(observation) {
  var card = document.createElement("div");
  card.className = "card";
  card.id = observation.id;

  card.appendChild(cardImg(observation.photoUrl));
  card.appendChild(
    cardBody(
      observation.name,
      observation.date,
      observation.uri,
      observation.wikipediaUrl
    )
  );
  card.appendChild(
    cardIcons(
      observation.isNative,
      observation.isIntroduced,
      observation.isThreatened,
      observation.isEndangered
    )
  );

  return card;
}

function cardImg(url) {
  var div = document.createElement("div");
  div.style.backgroundImage = "url(" + url.replace("square", "medium") + ")";
  div.className = "card-img";
  return div;
}

function cardBody(name, date, uri, wikipediaUrl) {
  var BodyCard = document.createElement("div");
  BodyCard.className = "card-body";

  var h3 = document.createElement("h3");
  h3.appendChild(createAnchor(wikipediaUrl, name));
  BodyCard.appendChild(h3);

  var h4 = document.createElement("h4");
  h4.appendChild(createAnchor(uri, date.toLocaleDateString()));
  BodyCard.appendChild(h4);

  return BodyCard;
}

function cardIcons(isNative, isIntroduced, isThreatened, isEndangered) {
  var div = document.createElement("div");
  div.className = "card-icons";

  if (isNative) {
    var icon = document.createElement("i");
    icon.className = "fas fa-leaf";
    icon.title = "Native";
    div.appendChild(icon);
  }
  if (isIntroduced) {
    var icon = document.createElement("i");
    icon.className = "fas fa-frog";
    icon.title = "Introduced";
    div.appendChild(icon);
  }
  if (isThreatened) {
    var icon = document.createElement("i");
    icon.className = "fas fa-radiation-alt";
    icon.title = "Threatened";
    div.appendChild(icon);
  }
  if (isEndangered) {
    var icon = document.createElement("i");
    icon.className = "fas fa-skull-crossbones";
    icon.title = "Endangered";
    div.appendChild(icon);
  }

  return div;
}
