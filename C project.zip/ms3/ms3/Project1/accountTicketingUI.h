// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================

#ifndef ACCOUNT_TICKETING_UI
#define ACCOUNT_TICKETING_UI
#include "ticket.h"
#include "account.h"
#define MAX_TICKET_SIZE 17


struct AccountTicketingData
{
	struct Account* accounts; // array of accounts
	const int ACCOUNT_MAX_SIZE; // maximum elements for account array-
	struct Ticket* tickets; // array of tickets
	const int TICKET_MAX_SIZE; // maximum elements for ticket array
};


void displayAccountSummaryHeader(void); 
// displays the header of a short summary of an account (only account#, type and birth date)

void displayAccountDetailHeader(void);
// displays the header of a full summary of an account (only account#, type, birth date, income, country of residence, disp name, login and password)

void displayListTicketsCustomerHeader(void); // displays header of all customer tickets for customer menu.

void displayListTicketsAgentHeader(void);



void displayAccountSummaryRecord(const struct Account*);
// displays the actual data of the short summary of an account(s) it takes the data from the argument constant struct pointer.

void displayAccountDetailRecord(const struct Account*);
// displays the actual data of the full summary of an account(s) it takes the data from the argument constant struct pointer.

void displayListTicketsCustomerRecord(const struct Ticket* ticket);

void displayListTicketsAgentRecord(const struct Ticket* ticket);


void displayTicketDataHeader(const struct Ticket* ticket); // display header customer chat history





void applicationStartup(struct AccountTicketingData* data);

int menuLogin(const struct Account account[], int maxElements);

void menuAgent(struct AccountTicketingData* data, const struct Account*);

int findAccountIndexByAcctNum(int accountNum, const struct Account account[], int maxElements, int promptUser);

void displayAllAccountSummaryRecords(struct AccountTicketingData* data);

void displayAllAccountDetailRecords(struct AccountTicketingData* data);

 

// Pause execution until user enters the enter key
void pauseExecution(void);


void menuCustomer(struct Ticket* ticket, const struct Account* accountPointer);




#endif // !ACCOUNT_TICKETING_UI
