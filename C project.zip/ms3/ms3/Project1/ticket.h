// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================

#ifndef TICKET_
#define TICKET_



#define DETAILS_SIZE 150
#define SUPPORT_TEXT_SIZE 30
#define NUM_OF_MSG_SIZE 20
#define ACCOUNTHOLDER_SIZE 30



struct Message
{
	char accntType;
	char accountHolder[ACCOUNTHOLDER_SIZE + 1];
	char msgDetails[DETAILS_SIZE + 1];
	


};

struct Ticket
{
	
	int ticketNumber;
	int accntNumber;
	int statusIndicator;
	char supportText[SUPPORT_TEXT_SIZE + 1];
	int numOfMsg;
	struct Message msg[NUM_OF_MSG_SIZE];
	
	
};


#endif