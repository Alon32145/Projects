// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_NONSTDC_NO_DEPRECATE
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "account.h"
#include "accountTicketingUI.h"
#include "commonHelpers.h"
#include "ticket.h"


