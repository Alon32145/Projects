// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "commonHelpers.h"

#include <time.h>
#include "account.h"

#define MAX_CHAR_SIZE 600

 // This function is getting current time which will be needed to determine the age of each user.
int currentYear(void)
{
	time_t currentTime = time(NULL);
	return localtime(&currentTime)->tm_year + 1900;
}
// clears the output buffer when is used after a scanf.
void clearStandardInputBuffer(void)
{
	while (getchar() != '\n')
	{
		; // On purpose: do nothing
	}
}
// validates if the user entered an integer value.
int getInteger(void)
{
	int value;
	char newLine = 'x';

	do
	{
		scanf("%d%c", &value, &newLine);
		if (newLine != '\n')
		{
			clearStandardInputBuffer();
			printf("ERROR: Value must be an integer: ");

		}
		

	} while (newLine != '\n');
	return value;
}
// expands on getInteger function by validating if the user entered an positive integer value.
int getPositiveInteger(void)
{
	int value;
	do
	{
		scanf("%d", &value);

		if (value < 0)
		{

			printf("ERROR: Value must be positive or zero: ");
		}
	} while (value < 0);

	return value;
}
// validates if the user entered an double value.
double getDouble(void)
{
	double value;
	char newLine = 'x';

	do
	{
		scanf("%lf%c", &value, &newLine);
		if (newLine != '\n')
		{
			clearStandardInputBuffer();
			printf("ERROR: Value must be a double floating-point number: ");

		}


	} while (newLine != '\n');
	return value;
}
// expands on getDouble function by validating if the user entered an positive double value.

double getPositiveDouble(void)
{

	double value = getDouble();
	if (value <= 0.0)
	{
		printf("ERROR: Value must be a positive double floating-point number: ");
		do
		{
			scanf("%lf", &value);

			if (value <= 0)
			{
				printf("ERROR: Value must be a positive double floating-point number: ");
			}
		} while (value <= 0);
	}


	return value;
}
// validates if user entered integer data is whithin the allowed range of numbers.
int getIntFromRange(int lowerBound, int upperBound)
{

	int value;
	
	do
	{
		value = getInteger();
	
		if (value < lowerBound || value > upperBound)
		{
			
			printf("ERROR: Value must be between %d and %d inclusive: ", lowerBound, upperBound);

		}
		
	} while ( value < lowerBound || value > upperBound);
	return value;
}
// validates if user entered character matches the allowed charcters.
char getCharOption(const char charOption[])
{
	int i;
	char value;
	char newline;
	int valid = 0;
	int displayerror = 0;
	do
	{
		scanf(" %c%c", &value, &newline);


		if (newline == '\n')
		{
			for (i = 0; charOption[i] != '\0'; i++)
			{
				if (valid == 0)
				{
					if (value == charOption[i])
					{
						valid = 1;
						displayerror = 1;
					}
					else
					{
						displayerror = 0;
					}
				}

			}
			if (displayerror == 0)
			{
				printf("ERROR: Character must be one of [%s]: ", charOption);
			}
		}
		else
		{
			clearStandardInputBuffer();
			printf("ERROR: Character must be one of [%s]: ", charOption);
		}

	} while (valid == 0);

	return value;
}

// validates if user entered data is within a spesific allowed number of characters wllowed to be typed.
void getCString(char* cString, int minChars, int maxChars)
{
	int i;

	if (minChars == maxChars)
	{
		do
		{
			scanf("%[^\n]s", cString);

			for (i = 0; cString[i] != '\0'; i++);
			if (i != maxChars)
			{
				printf("ERROR: String length must be exactly %d chars: ", maxChars);
			}
			clearStandardInputBuffer();
		} while (i != maxChars);
	}
	else if (minChars == 3)
	{
		char charInput[MAX_CHAR_SIZE];
		do
		{

			scanf(" %600[^\n]s", charInput);

			for (i = 0; charInput[i] != '\0'; i++);
			if (i > maxChars)
			{
				printf("ERROR: String length must be no more than %d chars: ", maxChars);
			}
			else
			{
				for (i = 0; i < maxChars; i++)
				{
					cString[i] = charInput[i];
				}

			}
			clearStandardInputBuffer();
		} while (i > maxChars);
	}
	else
	{
		do
		{
			scanf(" %600[^\n]s", cString);

			for (i = 0; cString[i] != '\0'; i++);
			if (i < minChars || i > maxChars)
			{
				printf("ERROR: String length must be between %d and %d chars: ", minChars, maxChars);
			}
			clearStandardInputBuffer();
		} while (i < minChars || i > maxChars);
	}
	
}
