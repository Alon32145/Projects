// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================

#ifndef ACCOUNT_H_
#define ACCOUNT_H_

#include "ticket.h"
#include "account.h"

#define RESIDENCE_SIZE 30
#define LOGIN_SIZE 10
#define PASSWORD_SIZE 8
#define MAX_ACCOUNT_SIZE 15
#define ACCOUNTHOLDER_SIZE 30
#define DATAFILE "accounts.txt"






struct Demographic // struct which stores 3 related demographic data types.
{
	int customerBirthYear;
	double householdIncome;
	char countryResidence[RESIDENCE_SIZE + 1];
};

struct UserLogin // struct which stores 3 related login data types.
{
	char accountHolder[ACCOUNTHOLDER_SIZE + 1];
	char loginName[LOGIN_SIZE + 1];
	char userPassword[PASSWORD_SIZE + 1];
};
// struct which stores 3 related account data types and the previous userLogin and Demographic struct types.
struct Account
{
	int accountNum;
	char accountType;
	struct UserLogin userLoginStruct;
	struct Demographic demographic;

};

void getAccount(struct Account* accountPointer);
// This function is responsible for taking account input from the user and store it in the appropriate struct which is account.
void getUserLogin(struct Account* accountPointer);
// This function is responsible for taking UserLogin input from the user and store it in the appropriate struct which is UserLogin.
// (NOTE: in main it accses UserLogin struct type through Account Struct type.)
void getDemographic(struct Account* accountPointer);
// This function is responsible for taking Demographic input from the user and store it in the appropriate struct which is Demographic.
// (NOTE: in main it accses Demographic struct type through Account Struct type.)



void updateAccount(struct Account*);

void updateUserLogin(struct Account*);

void updateDemographic(struct Account*);

void updatePassword(struct Account* accountPointer);

void updateCountry(struct Account* accountPointer);

void updateTicket(struct Ticket* ticket, const struct Account* accountPointer);

void updateAgentTickets(struct Ticket* , const struct Account* );

void getTicket(struct Ticket* ticket, const struct Account* accountPointer);



//void updateTicket(struct Ticket* ticket, const struct Account* accountPointer);
#endif // !ACCOUNT_H_
