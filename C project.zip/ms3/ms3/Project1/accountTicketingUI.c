// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

#include "commonHelpers.h"
#include "account.h"
#include "accountTicketingUI.h"
#include "ticket.h"




// displays the header of a short summary of an account (only account#, type and birth date)
void displayAccountSummaryHeader(void)
{

    printf("Acct# Acct.Type Birth\n");
    printf("----- --------- -----\n");
}
// displays the header of a full summary of an account (only account#, type, birth date, income, country of residence, disp name, login and password)
void displayAccountDetailHeader(void)
{
    printf("Acct# Acct.Type Birth Income      Country    Disp.Name       Login      Password\n");
    printf("----- --------- ----- ----------- ---------- --------------- ---------- --------\n");
}

void displayListTicketsCustomerHeader(void)
{
    printf("------ ------ ------------------------------ --------\n");
    printf("Ticket Status Subject                        Messages\n");
    printf("------ ------ ------------------------------ --------\n");
}

void displayListTicketsAgentHeader(void)
{
    printf("------ ----- --------------- ------ ------------------------------ --------\n");
    printf("Ticket Acct# Display Name    Status Subject                        Messages\n");
    printf("------ ----- --------------- ------ ------------------------------ --------\n");
}



// displays the actual data of the short summary of an account(s) it takes the data from the argument constant struct pointer.
void displayAccountSummaryRecord(const struct Account* accountPointer)
{
    
    
        if (accountPointer->accountType == 'C')
        {
            char localaccountType[9] = "CUSTOMER";
            printf("%05d %-9s %5d\n", accountPointer->accountNum, localaccountType, accountPointer->demographic.customerBirthYear);
        }
        else
        {
            char localaccountType[9] = "AGENT";
            printf("%05d %-9s %5d\n", accountPointer->accountNum, localaccountType, accountPointer->demographic.customerBirthYear);
        }
    
    
}

// displays the actual data of the full summary of an account(s) it takes the data from the argument constant struct pointer.
void displayAccountDetailRecord(const struct Account* accountPointer)
{
    int i;
    char localPass[9];
    if (accountPointer->accountType == 'C')
    {
        for ( i = 0; i < 9; i++)
        {
            localPass[i] = accountPointer->userLoginStruct.userPassword[i];
            if (i % 2 != 0)
            {
                localPass[i] = '*';
            }
            
        }
        

        char localaccountType[9] = "CUSTOMER";
        printf("%05d %-9s %5d $%10.2lf %-10s %-15s %-10s %8s\n", accountPointer->accountNum, localaccountType, accountPointer->demographic.customerBirthYear, accountPointer->demographic.householdIncome, accountPointer->demographic.countryResidence, accountPointer->userLoginStruct.accountHolder, accountPointer->userLoginStruct.loginName, localPass);
    }
    else 
    {
        for (i = 0; i < 9; i++)
        {
            localPass[i] = accountPointer->userLoginStruct.userPassword[i];
            if (i % 2 != 0)
            {
                localPass[i] = '*';
            }

        }
        char localaccountType[9] = "AGENT";
        printf("%05d %-9s %5d $%10.2lf %-10s %-15s %-10s %8s\n", accountPointer->accountNum, localaccountType, accountPointer->demographic.customerBirthYear, accountPointer->demographic.householdIncome, accountPointer->demographic.countryResidence, accountPointer->userLoginStruct.accountHolder, accountPointer->userLoginStruct.loginName, localPass);

    }
}


void displayListTicketsCustomerRecord(const struct Ticket* ticket) // displays brief summary of avaliable customer tickets
{
    
    if (ticket->statusIndicator == 1)
    {
        char status[7] = "ACTIVE";
        printf("%06d %-6s %-30s %5d\n", ticket->ticketNumber, status, ticket->supportText, ticket->numOfMsg);
        
    }
    else
    {
        char status[7] = "CLOSED";
        printf("%06d %-6s %-30s %5d\n", ticket->ticketNumber, status, ticket->supportText, ticket->numOfMsg);
        
    }
    
}


void displayTicketDataHeader(const struct Ticket* ticket) // displays both the header and the text inside each chosen ticket
{
    int i;

    if (ticket->statusIndicator == 1)
    {
        char status[9] = "(OPEN)";
        printf("================================================================================\n");
        printf("%06d %s Re: %s\n", ticket->ticketNumber, status, ticket->supportText);
        printf("================================================================================\n");

        for (i = 0 ; i < ticket->numOfMsg; i++)
        {
            if (ticket->msg[i].accntType == 'C')
            {
                char localaccountType[9] = "CUSTOMER";
                printf("%s (%s):\n   %s\n\n", localaccountType, ticket->msg[i].accountHolder, ticket->msg[i].msgDetails);
                
            }
            
            else if (ticket->msg[i].accntType == 'A')
            {
                
                char localaccountType[9] = "AGENT";
                
                printf("%s (%s):\n   %s\n\n", localaccountType, ticket->msg[i].accountHolder, ticket->msg[i].msgDetails);
            }
           if ((i+1) % 5 == 0) // asks to press enter every 5 msgs 
            {
                if (i == 0 )
                {
                    ;
                }
                else
                {
                    pauseExecution();
                }
            
            }
           
        }
        if (ticket->numOfMsg < NUM_OF_MSG_SIZE && ticket->numOfMsg % 5 != 0 )
        {
            pauseExecution();
        }
    
    }
    else
    {
        char status[9] = "(CLOSED)";
        printf("================================================================================\n");
        printf("%06d %s Re: %s\n", ticket->ticketNumber, status, ticket->supportText);
        printf("================================================================================\n");
        for (i = 0; i < ticket->numOfMsg; i++)
        {
            if (ticket->msg[i].accntType == 'C')
            {
                char localaccountType[9] = "CUSTOMER";
                printf("%s (%s):\n   %s\n\n", localaccountType, ticket->msg[i].accountHolder, ticket->msg[i].msgDetails);

            }

            else if (ticket->msg[i].accntType == 'A')
            {

                char localaccountType[9] = "AGENT";
                printf("%s (%s):\n   %s\n\n", localaccountType, ticket->msg[i].accountHolder, ticket->msg[i].msgDetails);
            }

            if ((i + 1) % 5 == 0) // asks to press enter every 5 msgs 
            {
                if (i == 0)
                {
                    ;
                }
                else
                {
                    pauseExecution();
                }

            }

        }
        if (ticket->numOfMsg < NUM_OF_MSG_SIZE && ticket->numOfMsg % 5 != 0)
        {
            pauseExecution();
        }

    }
}

void displayListTicketsAgentRecord(const struct Ticket* ticket) // extends on displayListTicketsCustomerRecord by showing also account# and login name. for agent menu
{

    if (ticket->statusIndicator == 1)
    {
        char status[7] = "ACTIVE";
        printf("%06d %05d %-15s %-6s %-30s %5d\n", ticket->ticketNumber, ticket->accntNumber, ticket->msg[0].accountHolder, status, ticket->supportText, ticket->numOfMsg);

    }
    else if (ticket->statusIndicator == 0)
    {
        char status[7] = "CLOSED";
        printf("%06d %05d %-15s %-6s %-30s %5d\n", ticket->ticketNumber, ticket->accntNumber, ticket->msg[0].accountHolder, status, ticket->supportText, ticket->numOfMsg);

    }
}
//===================================================================================================== Milestone 4

void pauseExecution(void)
{
    printf("<< ENTER key to Continue... >>");
    clearStandardInputBuffer();
    putchar('\n');
}

void applicationStartup(struct AccountTicketingData *data) // application start point
{
    
    
    int menuLoginIndex;
    
    do
    {
        menuLoginIndex = menuLogin(data->accounts, data->ACCOUNT_MAX_SIZE);

        if (data->accounts[menuLoginIndex].accountType == 'C')
        {
            menuCustomer(data->tickets, &data->accounts[menuLoginIndex]);
        }
        else if(menuLoginIndex != -1)
        {
            menuAgent(data, &data->accounts[menuLoginIndex]);

        }
    } while (menuLoginIndex != -1);
    
}

int menuLogin(const struct Account account[], int maxElements) // This menu is responsible with prompting user if he wants to login exit the program.
{
    int localChoice, i;
    char localCharChoice = 'x';
    int matchIsFound;
    int flag = 0;
    char userLogin[LOGIN_SIZE+1], userPass[PASSWORD_SIZE+1];
    struct UserLogin accountCredentials;
    
    {
        
        printf("==============================================\n");
        printf("Account Ticketing System - Login\n");
        printf("==============================================\n");
        printf("1) Login to the system\n");
        printf("0) Exit application\n");
        printf("----------------------------------------------\n\n");
        printf("Selection: ");

        localChoice = getIntFromRange(0, 1);

        if (localChoice == 0)
        {
            printf("\nAre you sure you want to exit? ([Y]es|[N]o): ");
            localCharChoice = getCharOption("yYnN");
            if (localCharChoice == 'Y' || localCharChoice == 'y')
            {
                printf("\n==============================================\n");
                printf("Account Ticketing System - Terminated\n");
                printf("==============================================\n");
                flag = 1;
                matchIsFound = -1;
            }
            else
            {
                
                putchar('\n');
            }
        }
        else if(localChoice == 1)
        {
            i = 3;
            while (i > 0)
            {
                
                printf("\nEnter the account#: ");
                matchIsFound = findAccountIndexByAcctNum(-1, account, maxElements, 1);
                printf("User Login    : ");
                scanf("%s", userLogin);
                clearStandardInputBuffer();
                printf("Password      : ");
                scanf("%s", userPass);
                clearStandardInputBuffer();


                if (matchIsFound == -1) // This part makes sure that the user entered account# matches the current given account#
                {
                    printf("INVALID user login/password combination! [attempts remaining:%d]\n", --i);

                }
                else // if first part is false it goes to second step of validation where it compares user entered name and password with given user name and password by the findAccountIndexByAcctNum function.
                {
                    accountCredentials = account[matchIsFound].userLoginStruct;
                    if (strcmp(accountCredentials.loginName, userLogin) !=0)
                    {
                        printf("INVALID user login/password combination! [attempts remaining:%d]\n", --i);
                    }
                    else if (strcmp(accountCredentials.userPassword, userPass) != 0)
                    {
                        printf("INVALID user login/password combination! [attempts remaining:%d]\n", --i);
                    }
                    else
                    {
                        i = -1;
                        flag = 1;
                        printf("\n");
                    }
  
                }
                 
            }
            if (i == 0)
            {
                printf("\nERROR:  Login failed!\n\n");
                pauseExecution();
            }
            
        }
        
    } while ( flag != 1);


    return matchIsFound;
}

int findAccountIndexByAcctNum(int accountNum, const struct Account account[], int maxElements, int promptUser) // function responsible for comparing user input with given database
{
    int i, index = -1;
    if (promptUser != 0)
    {
        
        accountNum = getInteger();
        
    }
    
    
    for ( i = 0; i < maxElements; i++)
    {
      if (accountNum == account[i].accountNum)
      {
          index = i;
      }
    }
    return index;
    
}

void menuAgent(struct AccountTicketingData* data, const struct Account* accountPointer) //menu of agent
{
    
    int matchIsFound;
    char getChar;
    int localChoice, i, flag, index;
    int accountNumChoice;

    do
    {
        printf("AGENT: %s (%d)\n", accountPointer->userLoginStruct.accountHolder, accountPointer->accountNum);
        printf("==============================================\n");
        printf("Account Ticketing System - Agent Menu\n");
        printf("==============================================\n");
        printf(" 1) Add a new account\n");
        printf(" 2) Modify an existing account\n");
        printf(" 3) Remove an account\n");
        printf(" 4) List accounts: summary view\n");
        printf(" 5) List accounts: detailed view\n");
        printf("----------------------------------------------\n");
        printf(" 6) List new tickets\n");
        printf(" 7) List active tickets\n");
        printf(" 8) List closed tickets\n");
        printf(" 9) Manage a ticket\n");
        printf("10) Archive closed tickets\n");
        printf("----------------------------------------------\n");
        printf("0) Logout\n\n");
        printf("Selection: ");
        localChoice = getIntFromRange(0, 9);
        switch (localChoice)
        {
        case 1:
            
            for ( i = 0, flag = 0 ; i < (MAX_ACCOUNT_SIZE); i++)
            {
                if (data->accounts[i].accountNum == 0)
                {
                    flag = 1;
                };
            }
            if (flag == 0)
            {
                printf("\nERROR: Account listing is FULL, call ITS Support!\n\n");
            }
            else
            {
                putchar('\n');
                getAccount(data->accounts);
                getUserLogin(data->accounts);
                getDemographic(data->accounts);

                putchar('\n');
                printf("*** New account added! ***");
                putchar('\n');
                putchar('\n');

            }
            
 
            pauseExecution();
         
           
            break;
        case 2:
            printf("\nEnter the account#: ");
            matchIsFound = findAccountIndexByAcctNum(-1, data->accounts, data->ACCOUNT_MAX_SIZE, 1); // findAccountIndexByAcctNum compares if the account# entered by agent matches database
            
      
            if (matchIsFound != -1) // if the above function gives a non -1 value it will call update account function which will allow to modify the required user data.
            {
                putchar('\n');
                updateAccount(&data->accounts[matchIsFound]);
            }
            else
            {
                printf("\nERROR:  Access Denied.\n\n");
            }
            
           break;
        case 3:
            printf("\nEnter the account#: ");
            matchIsFound = findAccountIndexByAcctNum(-1, data->accounts, data->ACCOUNT_MAX_SIZE, 1); // findAccountIndexByAcctNum compares if the account# entered by agent matches database

            if (data->accounts[matchIsFound].accountNum == accountPointer->accountNum) // if account# of the requested account matches the account# of the current logged in agent error will be displayed
            {
                printf("\nERROR: You can't remove your own account!\n\n");
                pauseExecution();
                putchar('\n');
            }
            else // else a detailed data of the account will be displayed supported by a final question if the user wishes to remove account
            {
                displayAccountDetailHeader();
                displayAccountDetailRecord(&data->accounts[matchIsFound]);
                printf("\nAre you sure you want to remove this record? ([Y]es|[N]o): ");
                getChar = getCharOption("YN");
                if (getChar == 'Y')
                {
                    for ( i = 0; i < MAX_TICKET_SIZE; i++)
                    {
                        if (data->accounts[matchIsFound].accountNum == data->tickets[i].accntNumber)// will need to improve
                        {
                            if (data->tickets[i].statusIndicator == 1)
                            {
                                data->tickets[i].ticketNumber = 0;
                            }
                            
                        }
                    }
                   
                    

                    data->accounts[matchIsFound].accountNum = 0;
                    printf("\n*** Account Removed! ***\n\n");
                    pauseExecution();
                    
                }
                else
                {
                    printf("\n*** No changes made! ***\n\n");
                    pauseExecution();
                }
            }
            break;
        case 4: // displayes brief data of all users
            putchar('\n');
            displayAllAccountSummaryRecords(data);
            putchar('\n');
            pauseExecution();
            
            break;
        case 5: // displayes detailed data of all users
            putchar('\n');
            displayAllAccountDetailRecords(data);
            putchar('\n');
            pauseExecution();
            break;
        case 6 : // displayes all new tickets open tickets with 1 message 

            do
            {

            
            putchar('\n');
            displayListTicketsAgentHeader();
            for ( i = 0; i < MAX_ACCOUNT_SIZE; i++)
            {

                if (data->tickets[i].numOfMsg == 1)
                {

                    matchIsFound = findAccountIndexByAcctNum(data->tickets[i].accntNumber, data->accounts, data->ACCOUNT_MAX_SIZE, 0);
                    displayListTicketsAgentRecord(&data->tickets[i]);     
                }
                
            }
            printf("------ ----- --------------- ------ ------------------------------ --------\n"); // prints - to close
            printf("\nEnter the ticket number to view the messages or\n0 to return to previous menu: "); // asks user which ticket he would like to view from the avaliable list
            accountNumChoice = getPositiveInteger();
            putchar('\n');

            for (i = 0, flag = 0; i < MAX_ACCOUNT_SIZE; i++)
            {

                if (accountNumChoice == data->tickets[i].ticketNumber) // if ticket# is valid it will set flag to 1 and index to the index# of the valid ticket
                {
                    index = i;
                    flag = 1;
                    if (accountNumChoice == 0) // if user enters zero flag is set to 2 and will exit the do while loop
                    {
                        flag = 2;
                    }
                }
                else if (accountNumChoice == 0) // if user enters zero flag is set to 2 and will exit the do while loop
                {
                    flag = 2;
                }
            }
            if (flag == 1) // if flag is 1 the correct ticket# is entered so the function which displays the text of the ticket will be called
            {
                displayTicketDataHeader(&data->tickets[index]);
                
            }
            else if (flag == 0) // otherwise if flag is 0 wrong ticket# is entered it will print a error message 
            {
                
                printf("ERROR: Invalid ticket number.\n");
                putchar('\n');
                pauseExecution();
            }
            
            } while (accountNumChoice !=0); // loop will end if user input is zero
            break;
        case 7 : // displays all active tickets

            do
            {


                putchar('\n');
                displayListTicketsAgentHeader();
                for (i = 0; i < MAX_TICKET_SIZE; i++)
                {

                    if (data->tickets[i].numOfMsg >= 1) // loops through index to find tickets with more than one message
                    {
                        if (data->tickets[i].statusIndicator == 1) // makes sure that all the tickets that have more than 1 message have a open status
                        {
                            if (data->tickets[i].ticketNumber != 0) // makes sure all tickets have a non-zero value
                            {
                                matchIsFound = findAccountIndexByAcctNum(data->tickets[i].accntNumber, data->accounts, data->ACCOUNT_MAX_SIZE, 0);
                                displayListTicketsAgentRecord(&data->tickets[i]);
                            }
                            
                        }
                    }

                }
                printf("------ ----- --------------- ------ ------------------------------ --------\n"); // prints - to close
                printf("\nEnter the ticket number to view the messages or\n0 to return to previous menu: ");// asks user which ticket he would like to view from the avaliable list
                accountNumChoice = getPositiveInteger();
                clearStandardInputBuffer();

                for (i = 0, flag = 0; i < MAX_TICKET_SIZE; i++)
                {

                    if (accountNumChoice == data->tickets[i].ticketNumber)// if ticket# is valid it will set flag to 1 and index to the index# of the valid ticket
                    {
                        index = i;
                        flag = 1;
                        if (accountNumChoice == 0)// if user enters zero flag is set to 2 and will exit the do while loop
                        {
                            flag = 2;
                        }
                    }
                    else if (accountNumChoice == 0) // if user enters zero flag is set to 2 and will exit the do while loop
                    {
                        flag = 2;
                        
                    }
                }
                if (flag == 1) // if flag is 1 the correct ticket# is entered so the function which displays the text of the ticket will be called
                {
                    putchar('\n');
                    displayTicketDataHeader(&data->tickets[index]);
                    
                }
                else if (flag == 0) // otherwise if flag is 0 wrong ticket# is entered it will print a error message
                {
                    putchar('\n');
                    printf("ERROR: Invalid ticket number.\n");
                    putchar('\n');
                    pauseExecution();
                }
                if(accountNumChoice == 0)
                {
                    putchar('\n');
                }


            } while (accountNumChoice != 0); // loop will end if user input is zero
            break;
        case 8 :
            do
            {

                putchar('\n');
                putchar('\n');
                displayListTicketsAgentHeader();
                for (i = 0; i < MAX_TICKET_SIZE; i++)
                {

                    if (data->tickets[i].numOfMsg >= 1) // loops through index to find tickets with more than one message
                    {
                        if (data->tickets[i].statusIndicator == 0) // makes sure that all the tickets that have more than 1 message have a open status
                        {
                            matchIsFound = findAccountIndexByAcctNum(data->tickets[i].accntNumber, data->accounts, data->ACCOUNT_MAX_SIZE, 0);
                            displayListTicketsAgentRecord(&data->tickets[i]);
                        }
                    }

                }
                printf("------ ----- --------------- ------ ------------------------------ --------\n"); // prints - to close
                printf("\nEnter the ticket number to view the messages or\n0 to return to previous menu: ");// asks user which ticket he would like to view from the avaliable list
                accountNumChoice = getPositiveInteger();
                clearStandardInputBuffer();

                for (i = 0, flag = 0; i < MAX_TICKET_SIZE; i++)
                {

                    if (accountNumChoice == data->tickets[i].ticketNumber)// if ticket# is valid it will set flag to 1 and index to the index# of the valid ticket
                    {
                        index = i;
                        flag = 1;
                        if (accountNumChoice == 0)// if user enters zero flag is set to 2 and will exit the do while loop
                        {
                            flag = 2;
                        }
                    }
                    else if (accountNumChoice == 0) // if user enters zero flag is set to 2 and will exit the do while loop
                    {
                        flag = 2;

                    }
                }
                if (flag == 1) // if flag is 1 the correct ticket# is entered so the function which displays the text of the ticket will be called
                {
                    
                    displayTicketDataHeader(&data->tickets[index]);

                }
                else if (flag == 0) // otherwise if flag is 0 wrong ticket# is entered it will print a error message
                {
                    putchar('\n');
                    printf("ERROR: Invalid ticket number.\n");
                    putchar('\n');
                    pauseExecution();
                }
                if (accountNumChoice == 0)
                {
                    putchar('\n');
                }


            } while (accountNumChoice != 0); // loop will end if user input is zero
            break;
        case 9 :
            putchar('\n');
            updateAgentTickets(data->tickets, accountPointer);
            
            break;
        default:
            printf("\n### LOGGED OUT ###\n\n");
            break;
        }


    } while (localChoice != 0);
    


}

 // Pause execution until user enters the enter key
 

 void displayAllAccountSummaryRecords( struct AccountTicketingData* data) // using a for loop the function goes through all database information and shows all the requsted data to agent
 {
     int i;
    
     displayAccountSummaryHeader();
     for ( i = 0; i < MAX_ACCOUNT_SIZE; i++)
     {

         if (data->accounts[i].accountNum != 0)
         {
             displayAccountSummaryRecord(&data->accounts[i]);
         }
 
     }
     
 }

 void displayAllAccountDetailRecords( struct AccountTicketingData* data)// using a for loop the function goes through all database information and shows all the requsted detailed data to agent
 {
     int i;
     displayAccountDetailHeader();
     for (i = 0; i < MAX_ACCOUNT_SIZE; i++)
     {
         if (data->accounts[i].accountNum != 0)
         {
             displayAccountDetailRecord(&data->accounts[i]);
         }
     }
 }

 void menuCustomer(struct Ticket* ticket, const struct Account* accountPointer) // customers menu
 {
     
     int localChoice, i, ticketNum, flag, index ;
     do
     {
         printf("CUSTOMER: %s (%d)\n", accountPointer->userLoginStruct.accountHolder, accountPointer->accountNum);
         printf("==============================================\n");
         printf("Customer Main Menu\n");
         printf("==============================================\n");
         printf("1) View your account detail\n");
         printf("2) Create a new ticket\n");
         printf("3) Modify an active ticket\n");
         printf("4) List my tickets\n");
         printf("----------------------------------------------\n");
         printf("0) Logout\n\n");

         printf("Selection: ");
         localChoice = getIntFromRange(0, 9);
         
         switch (localChoice)
         {
         case 1:
             putchar('\n');
             displayAccountDetailHeader();
             displayAccountDetailRecord(accountPointer);
             putchar('\n');
             pauseExecution();
             break;
         case 2:
             putchar('\n');
             getTicket(ticket, accountPointer);
             
             
             pauseExecution();
             break;
         case 3:
             putchar('\n');
             updateTicket(ticket, accountPointer);

             
             break;

          case 4:
              putchar('\n');
             do
             {
                 
                 displayListTicketsCustomerHeader();
                 for (i = 0; i < MAX_TICKET_SIZE; i++)
                 {
                     if (accountPointer->accountNum == ticket[i].accntNumber) // loops through database to find all tickets that have matching account# to the one of the customer
                     {
                         
                         displayListTicketsCustomerRecord(&ticket[i]);
                     }
                 }

                 printf("------ ------ ------------------------------ --------\n"); // prints - to close
                 printf("\nEnter the ticket number to view the messages or\n0 to return to previous menu: ");// asks user which ticket he would like to view from the avaliable list
                 ticketNum = getPositiveInteger();
                 clearStandardInputBuffer();
                 
                 for ( i = 0, flag = 0 ; i < MAX_TICKET_SIZE; i++)
                 {

                     if (ticketNum == ticket[i].ticketNumber) // if user entered ticket# matches the ticket# displayed index will be set to the value of i which presents the index of the chosen ticket#. 
                     {// flag will be set to 1 for a later if statement 
                         if (accountPointer->accountNum == ticket[i].accntNumber)
                         {
                             index = i;
                             flag = 1;
                         }
                         
                         else if (ticketNum == 0) // if user entered ticket# is 0 flag is set to 2 so no message will be displayed when user exists
                         {
                             flag = 2;
                         }
                     }
                     else if (ticketNum == 0)// if user entered ticket# is 0 flag is set to 2 so no message will be displayed when user exists
                     {
                         flag = 2;
                     }


                 }
                 if (flag == 1) // if flag above set to 1 the function which will allow user to read the history of each ticket will be called
                 {
                     putchar('\n');
                     displayTicketDataHeader(&ticket[index]);
                     
                     
                 }
                 else if (flag == 0) // if invalid ticket# is entered error will be displayed
                 {
                     
                     printf("\nERROR: Invalid ticket number - you may only access your own tickets.\n");
                     putchar('\n');
                     pauseExecution();
                 }
                 else
                 {
                     putchar('\n');
                 }

             } while (flag !=2 ); // loops while flag is not 2

             break;
         default:
             printf("\n### LOGGED OUT ###\n\n");
             break;
         }
     } while (localChoice != 0);

}
