// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================

#ifndef COMMON_HELPERS_H_
#define COMMON_HELPERS_H_


int currentYear(void); // This function is getting current time which will be needed to determine the age of each user.
void clearStandardInputBuffer(void); // clears the output buffer when is used after a scanf.

int getInteger(void);// validates if the user entered an integer value.
int getPositiveInteger(void);// expands on getInteger function by validating if the user entered an positive integer value.

double getDouble(void);// validates if the user entered an double value.
double getPositiveDouble(void);// expands on getDouble function by validating if the user entered an positive double value.

int getIntFromRange(int lowerBound, int upperBound); // validates if user entered integer data is whithin the allowed range of numbers.

char getCharOption(const char charOption[]); // validates if user entered character matches the allowed charcters.

void getCString(char* Cstring, int minChars, int maxChars); // validates if user entered data is within a spesific allowed number of characters wllowed to be typed.
#endif // !COMMON_HELPERS_H_