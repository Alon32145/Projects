// ===================================================================================
//  Assignment: 2 
//  Milestone : 1
// ===================================================================================
//  Student Name  : Alon Raigorodetsky
//  Student ID    : 109763201
//  Student Email :araigorodetsky@myseneca.ca
//  Course Section: NDD
// ===================================================================================
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_NONSTDC_NO_DEPRECATE
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "account.h"
#include "accountTicketingUI.h"
#include "commonHelpers.h"
#include "ticket.h"




// This function is responsible for taking account input from the user and store it in the appropriate struct which is account.
void getAccount(struct Account* accountPointer)
{

    int i, found = 0;
    int IncremantedNum = accountPointer[0].accountNum;

    // Gets the highest account number
    for (i = 0; i < MAX_ACCOUNT_SIZE; i++)
    {
        if (accountPointer[i].accountNum > IncremantedNum)
        {
            IncremantedNum = accountPointer[i].accountNum;
        }
    }

    IncremantedNum += 1;
    for (i = 0; found == 0; i++)
    {
        if (accountPointer[i].accountNum == 0)
        {
            found = 1;
            printf("New Account Data (Account#:%d)\n", IncremantedNum);
            printf("----------------------------------------\n");

            printf("Enter the account type (A=Agent | C=Customer): ");
            accountPointer[i].accountType = getCharOption("AC");

            accountPointer[i].accountNum = IncremantedNum;
        }
    }
}

// This function is responsible for taking UserLogin input from the user and store it in the appropriate struct which is UserLogin.
// (NOTE: in main it accses UserLogin struct type through Account Struct type.)
void getUserLogin(struct Account* accountPointer)
{
    
    int i,x, found = 0;
    int IncremantedNum = accountPointer[0].accountNum;
    
    
    int valid;
   

    // Gets the highest account number
    for (i = 0; i < MAX_ACCOUNT_SIZE; i++)
    {
        if (accountPointer[i].accountNum > IncremantedNum)
        {
            IncremantedNum = accountPointer[i].accountNum;
        }
    }
    
    for (i = 0; found == 0; i++)
    {
        if (accountPointer[i].accountNum == IncremantedNum)
        {
            found = 1;
            printf("\nUser Login Data Input\n");
            printf("----------------------------------------\n");
            do {
                *accountPointer[i].userLoginStruct.loginName = '\0';
                valid = 1;
                printf("Enter user login (%d chars max): ", LOGIN_SIZE);
                getCString(accountPointer[i].userLoginStruct.loginName, 3, LOGIN_SIZE);

                for (x = 0; x < LOGIN_SIZE -1; x++)
                {
                    if (accountPointer[i].userLoginStruct.loginName[x] == ' ')
                    {
                        valid = 0;
                        printf("ERROR:  The user login must NOT contain whitespace characters.\n");
                    }
                    
                }
            } while (valid == 0);

            // enters display name
 
            printf("Enter the display name (%d chars max): ", ACCOUNTHOLDER_SIZE);
            getCString(accountPointer[i].userLoginStruct.accountHolder, 1, ACCOUNTHOLDER_SIZE);


            // Enters password
            
            updatePassword(&accountPointer[i]);

        }
    }
}
// This function is responsible for taking Demographic input from the user and store it in the appropriate struct which is Demographic.
// (NOTE: in main it accses Demographic struct type through Account Struct type.)
void getDemographic(struct Account* accountPointer)
{
    int i, found = 0;
    int IncremantedNum = accountPointer[0].accountNum;
    

    // Gets the highest account number
    for (i = 0; i < MAX_ACCOUNT_SIZE; i++)
    {
        if (accountPointer[i].accountNum > IncremantedNum)
        {
            IncremantedNum = accountPointer[i].accountNum;
        }
    }

    for (i = 0; found == 0; i++)
    {
        if (accountPointer[i].accountNum == IncremantedNum)
        {
            found = 1;
            printf("\nDemographic Data Input\n");
            printf("----------------------------------------\n");
            // enters age
            printf("Enter birth year (current age must be between 18 and 110): ");
            accountPointer[i].demographic.customerBirthYear = getIntFromRange(1911, 2003);


            // enters income

            printf("Enter the household Income: $");
            accountPointer[i].demographic.householdIncome = getPositiveDouble();


            // enters country of residence
            updateCountry(&accountPointer[i]);
        }
    }

}

void updateAccount(struct Account* accountPointer)
{
    int localChoice;

    do
    {
        printf("Account: %5d - Update Options\n", accountPointer->accountNum);
        printf("----------------------------------------\n");
        printf("1) Update account type (current value: %c)\n", accountPointer->accountType);
        printf("2) Login\n");
        printf("3) Demographics\n");
        printf("0) Done\n");
        printf("Selection: ");
        localChoice = getIntFromRange(0, 3);
        switch (localChoice)
        {
        case 1:
            printf("\nEnter the account type (A=Agent | C=Customer): ");
            accountPointer->accountType = getCharOption("AC");
            putchar('\n');
            break;
        case 2:
            updateUserLogin(accountPointer);
            break;
        case 3:
            updateDemographic(accountPointer);
            putchar('\n');
            break;
        default:
            putchar('\n');
            break;
        }


    } while (localChoice != 0);

}



void updateUserLogin(struct Account* accountPointer)
{
    int localChoice;
    
    do
    {

        printf("\nUser Login: %s - Update Options\n", accountPointer->userLoginStruct.loginName);
        printf("----------------------------------------\n");
        printf("1) Display name (current value: %s)\n", accountPointer->userLoginStruct.accountHolder);
        printf("2) Password\n");
        printf("0) Done\n");
        printf("Selection: ");
        localChoice = getIntFromRange(0, 3);
        putchar('\n');

        switch (localChoice)
        {
        case 1:
            printf("Enter the display name (30 chars max): ");
            getCString(accountPointer->userLoginStruct.accountHolder, 1, 30);
            break;
        case 2:
            updatePassword(accountPointer);

            
        default:
            break;
        }
    } while (localChoice != 0);

}



void updateDemographic(struct Account* accountPointer)
{
    int localChoice;
    do
    {
        printf("\nDemographic Update Options\n");
        printf("----------------------------------------\n");
        printf("1) Household Income (current value: $%.2lf)\n", accountPointer->demographic.householdIncome);
        printf("2) Country (current value: %s)\n", accountPointer->demographic.countryResidence);
        printf("0) Done\n");
        printf("Selection: ");
        localChoice = getIntFromRange(0, 3);

        switch (localChoice)
        {
        case 1:
            printf("\nEnter the household Income: $");
            accountPointer->demographic.householdIncome = getPositiveDouble();
            break;
        case 2:
            updateCountry(accountPointer); // updates country

            break;
        default:

            break;
        }
    } while (localChoice != 0);

}
void updatePassword(struct Account* accountPointer)
{
    int upper = 0, lower = 0, digit = 0, punct = 0, x;
    do {

        printf("Enter the password (must be %d chars in length): ", PASSWORD_SIZE);
        getCString(accountPointer->userLoginStruct.userPassword, PASSWORD_SIZE, PASSWORD_SIZE);

        for (x = 0, upper = 0, digit = 0, lower = 0, punct = 0; x < 9; x++) {
            if (isupper(accountPointer->userLoginStruct.userPassword[x]))
            {
                upper += 1;
            }
            if (isdigit(accountPointer->userLoginStruct.userPassword[x]))
            {
                digit += 1;
            }
            if (islower(accountPointer->userLoginStruct.userPassword[x]))
            {
                lower += 1;
            }
            if (ispunct(accountPointer->userLoginStruct.userPassword[x]))
            {
                punct += 1;
            }
        }
        if (upper != 2 || digit != 2 || lower != 2 || punct != 2) {
            printf("SECURITY: Password must contain 2 of each:\n");
            printf("          Digit: 0-9\n");
            printf("          UPPERCASE character\n");
            printf("          lowercase character\n");
            printf("          symbol character: !@#$%%^&*\n");
        }

    } while ((upper != 2 || digit != 2 || lower != 2 || punct != 2));

}
void updateCountry(struct Account* accountPointer)
{
    int x;
    printf("Enter the country (%d chars max.): ", RESIDENCE_SIZE);
    getCString(accountPointer->demographic.countryResidence, 1, RESIDENCE_SIZE);



    for (x = 0; x < RESIDENCE_SIZE; x++)
    {
        accountPointer->demographic.countryResidence[x] = toupper(accountPointer->demographic.countryResidence[x]);
    }

}

void getTicket(struct Ticket* ticket, const struct Account* accountPointer)
{
    int i, found =0;
    int IncremantedNum = ticket[0].accntNumber;
     

    // Gets the highest ticket number
    for (i = 0; i < MAX_TICKET_SIZE; i++)
    {
        //printf("%d\n", ticket[i].accntNumber);
        if (ticket[i].ticketNumber > IncremantedNum)
        {
            IncremantedNum = ticket[i].ticketNumber;
            
        }
    }

    IncremantedNum += 1;

    for (i = 0; found == 0; i++)
    {
        if (i >= MAX_TICKET_SIZE)
        {
            printf("ERROR: Ticket listing is FULL, call ITS Support!\n\n");
            found = 1;
        }
        else if (ticket[i].ticketNumber == 0)
        {

            found = 1;
            printf("New Ticket (Ticket#:%06d)\n", IncremantedNum);
            ticket[i].ticketNumber = IncremantedNum;
            printf("----------------------------------------\n");
            printf("Enter the ticket SUBJECT (%d chars. maximum): ", SUPPORT_TEXT_SIZE);
            getCString(ticket[i].supportText, 1, SUPPORT_TEXT_SIZE);
            putchar('\n');
            printf("Enter the ticket message details(%d chars.maximum).Press the ENTER key to\nsubmit :\n", DETAILS_SIZE);
            getCString(ticket[i].msg[0].msgDetails, 1, DETAILS_SIZE);
            
            ticket[i].msg[0].accntType = 'C';
            strcpy(ticket[i].msg[0].accountHolder , accountPointer->userLoginStruct.accountHolder);
            ticket[i].statusIndicator = 1;
            ticket[i].accntNumber = accountPointer->accountNum;
            ticket[i].numOfMsg = 1;
            printf("\n*** New ticket created! ***\n\n");
        }
    }
    
}
void updateTicket(struct Ticket* ticket, const struct Account* accountPointer)
{

    int ticketNum, selction = 0,j, i = 0, flag = 0;
    char getAnswer, closingMsg;
    printf("Enter ticket number: ");
    ticketNum = getPositiveInteger();
    clearStandardInputBuffer();
    do
    {
        
        i++;
        if (ticket[i].ticketNumber == ticketNum)
        {
            if (ticket[i].accntNumber == accountPointer->accountNum)
            {
                flag = 1;
            }
            else
            {
                flag = 2;
            }
        }
        


    } while (flag != 1 && flag != 2);
    
    if (flag == 1)
    {
        if (ticket[i].statusIndicator == 0)
        {
            printf("\nERROR: Ticket is closed - changes are not permitted.\n\n");
            pauseExecution();
        }
        else
        {

            do
            {
                printf("\n----------------------------------------\n");
                printf("Ticket %06d - Update Options\n", ticketNum);
                printf("----------------------------------------\n");


                if (ticket[i].statusIndicator == 1)
                {
                    char status[7] = "ACTIVE";
                    printf("Status  : %s\n", status);
                }
                else
                {
                    char  status[7] = "CLOSED";
                    printf("Status  : %s\n", status);
                }
                printf("Subject : %s\n", ticket[i].supportText);
                printf("----------------------------------------\n");
                printf("1) Modify the subject\n");
                printf("2) Add a message\n");
                printf("3) Close ticket\n");
                printf("0) Done\n");
                printf("Selection: ");

                selction = getIntFromRange(0, 3);
                putchar('\n');

                switch (selction)
                {
                case 1:
                    printf("Enter the revised ticket SUBJECT (%d chars. maximum): ", SUPPORT_TEXT_SIZE);

                    getCString(ticket[i].supportText, 1, SUPPORT_TEXT_SIZE);
                    break;
                case 2:
                    if (ticket[i].numOfMsg == NUM_OF_MSG_SIZE)
                    {
                        printf("ERROR: Message limit has been reached, call ITS Support!\n");
                    }
                    else
                    {
                        printf("Enter the ticket message details(%d chars.maximum).Press the ENTER key to\nsubmit :\n", DETAILS_SIZE);
                        j = ticket[i].numOfMsg;
                        ticket[i].numOfMsg += 1;
                        getCString(ticket[i].msg[j].msgDetails, 1, SUPPORT_TEXT_SIZE);
                        ticket[i].msg[j].accntType = 'C';
                        strcpy(ticket[i].msg[j].accountHolder, accountPointer->userLoginStruct.accountHolder);
                        
                    }

                    break;
                case 3:
                    printf("Are you sure you CLOSE this ticket? ([Y]es|[N]o): ");
                    getAnswer = getCharOption("YN");
                    if (getAnswer == 'Y')
                    {
                        
                        if (ticket[i].numOfMsg != NUM_OF_MSG_SIZE)
                        {
                            printf("\nDo you want to leave a closing message? ([Y]es|[N]o): ");
                            closingMsg = getCharOption("YN");
                            if (closingMsg == 'Y')
                            {
                                if (ticket[i].numOfMsg != NUM_OF_MSG_SIZE)
                                {
                                    printf("\nEnter the ticket message details(%d chars.maximum).Press the ENTER key to\nsubmit :\n", DETAILS_SIZE);
                                    j = ticket[i].numOfMsg;
                                    ticket[i].numOfMsg += 1;
                                    
                                    getCString(ticket[i].msg[j].msgDetails, 1, DETAILS_SIZE);
                                    ticket[i].msg[j].accntType = 'C';
                                    strcpy(ticket[i].msg[j].accountHolder, accountPointer->userLoginStruct.accountHolder);
                                }

                            }
                            
                        }
                        ticket[i].statusIndicator = 0;

                        selction = 0;
                        printf("\n*** Ticket closed! ***\n\n");
                        pauseExecution();

                    }
                    else
                    {
                        ;
                    }
                    break;
                default:
                    pauseExecution();
                    break;
                }

            } while (selction != 0);
        }
    }
    else
    {
        printf("\nERROR: Invalid ticket number - you may only modify your own ticket.\n\n");
        pauseExecution();
    }
     
}

void updateAgentTickets(struct Ticket* ticket, const struct Account* accountPointer)
{
    int ticketNum, selction = 0, j, i = 0, flag = 0, index = 0;
    char getAnswer, closingMsg;

    printf("Enter ticket number: ");
    ticketNum = getPositiveInteger();
    clearStandardInputBuffer();

    for ( i = 0, flag = 0; i < MAX_TICKET_SIZE; i++)
    {
        if(ticketNum == ticket[i].ticketNumber)
        {
            index = i;
            flag = 1;
        }
        
    }
    if (flag == 1)
    {
        do
        {

        
            printf("\n----------------------------------------\n");
            printf("Ticket %06d - Update Options\n", ticketNum);
            printf("----------------------------------------\n");


            if (ticket[index].statusIndicator == 1)
            {
                char status[7] = "ACTIVE";
                printf("Status  : %s\n", status);
            }
            else
            {
                char  status[7] = "CLOSED";
                printf("Status  : %s\n", status);
            }
            printf("Subject : %s\n", ticket[index].supportText);
            printf("Acct#   : %d\n", ticket[index].accntNumber);
            printf("Customer: %s\n", ticket[index].msg[0].accountHolder);
            printf("----------------------------------------\n");
            printf("1) Add a message\n");
            printf("2) Close ticket\n");
            printf("3) Re-open ticket\n");
            printf("0) Done\n");
            printf("Selection: ");
            selction = getIntFromRange(0, 3);
            putchar('\n');

            switch (selction)
            {
            case 1:
                if (ticket[index].statusIndicator == 0)
                {
                    printf("ERROR: Ticket is closed - new messages are not permitted.\n");
                }
                else
                {
                    if (ticket[index].numOfMsg == NUM_OF_MSG_SIZE)
                    {
                        printf("ERROR: Message limit has been reached, call ITS Support!\n");
                    }
                    else
                    {
                        printf("Enter the ticket message details(%d chars.maximum).Press the ENTER key to submit :\n", DETAILS_SIZE);
                        j = ticket[index].numOfMsg;
                        ticket[index].numOfMsg += 1;
                        getCString(ticket[index].msg[j].msgDetails, 1, DETAILS_SIZE);
                        ticket[index].msg[j].accntType = 'A';
                        strcpy(ticket[index].msg[j].accountHolder, accountPointer->userLoginStruct.accountHolder);
                    }
                    

                }
                
                break;
            case 2:
                if (ticket[index].statusIndicator == 0)
                {
                    printf("ERROR: Ticket is already closed!\n");
                }
                else
                {
                    printf("Are you sure you CLOSE this ticket? ([Y]es|[N]o): ");
                    getAnswer = getCharOption("YN");
                    if (getAnswer == 'Y')
                    {


                        if (ticket[index].numOfMsg != NUM_OF_MSG_SIZE)
                        {
                            printf("\nDo you want to leave a closing message? ([Y]es|[N]o): ");
                            closingMsg = getCharOption("YN");
                            if (closingMsg == 'Y')
                            {
                                if (ticket[index].numOfMsg != NUM_OF_MSG_SIZE)
                                {
                                    printf("\nEnter the ticket message details(%d chars.maximum).Press the ENTER key to submit :\n", DETAILS_SIZE);
                                    j = ticket[index].numOfMsg;
                                    ticket[index].numOfMsg += 1;

                                    getCString(ticket[index].msg[j].msgDetails, 1, DETAILS_SIZE);
                                    ticket[index].msg[j].accntType = 'C';
                                    strcpy(ticket[index].msg[j].accountHolder, accountPointer->userLoginStruct.accountHolder);
                                }

                            }

                        }
                        ticket[index].statusIndicator = 0;
                        printf("\n*** Ticket closed! ***\n\n");
                        
                    }
                    else
                    {
                        ;
                    }
                }
                
                break;
            case 3:
                if (ticket[index].statusIndicator == 1)
                {
                    printf("ERROR: Ticket is already active!\n");
                }
                else
                {
                    printf("Are you sure you RE-OPEN this closed ticket? ([Y]es|[N]o):");
                    getAnswer = getCharOption("YN");
                    if (getAnswer == 'Y')
                    {
                        printf("\n*** Ticket re-opened! ***\n");
                        ticket[index].statusIndicator = 1;
                    }
                }
            default:
                break;
            }
        } while (selction != 0);
    }
    else
    {
    printf("\nERROR: Invalid ticket number.\n\n");
    }
    
}

int loadAccounts(struct Account* accounts, int arrSize)
{
    
    FILE* fp = NULL;
    fp = fopen("accounts.txt", "r");
    if (fp == NULL)
    {
        printf("ERROR: Can't open accounts.txt file\n");

    }
    while (!feof(fp))
    {
        fscanf(fp, "%d|%*c|%d|%*c|%d|%d|%[^|]|%*c");
    }
}
